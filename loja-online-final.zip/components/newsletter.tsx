import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail } from "lucide-react"

export function Newsletter() {
  return (
    <section className="bg-gray-900 py-16">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Mail className="mx-auto h-12 w-12 text-white mb-4" />
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Fique por dentro das novidades</h2>
          <p className="mt-4 text-lg text-gray-300">
            Receba ofertas exclusivas, lançamentos e dicas tecnológicas diretamente no seu e-mail.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input type="email" placeholder="Seu melhor e-mail" className="flex-1 bg-white" />
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Inscrever-se
            </Button>
          </div>
          <p className="mt-4 text-sm text-gray-400">Não enviamos spam. Cancele a qualquer momento.</p>
        </div>
      </div>
    </section>
  )
}
