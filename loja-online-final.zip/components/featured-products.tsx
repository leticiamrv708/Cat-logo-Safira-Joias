
import Image from "next/image";

const products = [
  {
    name: "Chocker Corações",
    price: "R$ 69,90",
    image: "/images/chocker-coracoes.jpg",
  },
  {
    name: "Corrente Zircônica",
    price: "R$ 89,90",
    image: "/images/corrente-zirconica.jpg",
  },
  {
    name: "Pulseira Infinito",
    price: "R$ 129,90",
    image: "/images/pulseira-infinito.jpg",
  },
];

export default function FeaturedProducts() {
  return (
    <section className="py-10 bg-[var(--background-alt)]">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-6 text-[var(--primary)]">Destaques</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {products.map((product, idx) => (
            <div key={idx} className="bg-white rounded-2xl shadow p-4">
              <Image
                src={product.image}
                alt={product.name}
                width={400}
                height={400}
                className="rounded-xl object-cover"
              />
              <h3 className="mt-4 text-xl font-semibold text-[var(--text)]">{product.name}</h3>
              <p className="text-[var(--text-muted)]">{product.price}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
