import { Card, CardContent } from "@/components/ui/card"
import { Smartphone, Laptop, Headphones, Watch, Camera, Gamepad2 } from "lucide-react"

const categories = [
  {
    name: "Smartphones",
    icon: Smartphone,
    count: "120+ produtos",
    color: "bg-blue-500",
  },
  {
    name: "Laptops",
    icon: Laptop,
    count: "80+ produtos",
    color: "bg-green-500",
  },
  {
    name: "Fones de Ouvido",
    icon: Headphones,
    count: "150+ produtos",
    color: "bg-purple-500",
  },
  {
    name: "Smartwatches",
    icon: Watch,
    count: "60+ produtos",
    color: "bg-orange-500",
  },
  {
    name: "Câmeras",
    icon: Camera,
    count: "40+ produtos",
    color: "bg-red-500",
  },
  {
    name: "Games",
    icon: Gamepad2,
    count: "200+ produtos",
    color: "bg-indigo-500",
  },
]

export function Categories() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Categorias Populares</h2>
          <p className="mt-4 text-lg text-gray-600">Explore nossa ampla seleção de produtos tecnológicos</p>
        </div>
        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {categories.map((category) => {
            const Icon = category.icon
            return (
              <Card
                key={category.name}
                className="group cursor-pointer transition-all hover:shadow-lg hover:-translate-y-1"
              >
                <CardContent className="flex flex-col items-center p-6">
                  <div
                    className={`${category.color} rounded-full p-3 text-white mb-4 group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="font-semibold text-center text-sm sm:text-base">{category.name}</h3>
                  <p className="text-xs text-gray-500 mt-1">{category.count}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
